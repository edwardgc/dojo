#pragma once
#include <string>
#include <vector>

class Digit
{
	public:
		Digit(int p_num);
		std::string line0, line1, line2;
};

